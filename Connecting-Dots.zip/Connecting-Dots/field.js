export class Field {
    fieldText = "";
    color = "";

    constructor(fieldText, color) {
        this.fieldText = fieldText;
        this.color = color;
    }
}